import React from 'react'
import Eran_1 from '../Eran_1/Eran_1'

function Eran() {
  return (
    <div>
        <Eran_1/>
    </div>
  )
}

export default Eran