import React from 'react'
import Dash_Stats from '../Dash_Stats/Dash_Stats'
import Token from '../Token/Token'
import Composition_Table from '../Composition_Table/Composition_Table'

function Dashbord() {
  return (
    <div>
        <Dash_Stats/>
<Token/>
<Composition_Table/>
    </div>
  )
}

export default Dashbord